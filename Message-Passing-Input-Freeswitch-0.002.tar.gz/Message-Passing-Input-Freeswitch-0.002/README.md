Log-Stash-Input-FreeSWITCH
==========================

Pump FreeSWITCH events from the event socket into Log Stash